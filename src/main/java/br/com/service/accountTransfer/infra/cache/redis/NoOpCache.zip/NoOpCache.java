package br.com.service.accountTransfer.infra.cache.redis;

import org.springframework.cache.Cache;

import java.util.concurrent.Callable;

public class NoOpCache implements Cache {


    @Override
    public void clear() {

    }

    @Override
    public void evict(Object key) {

    }

    @Override
    public ValueWrapper get(Object key) {
        return null;
    }

    @Override
    public <T> T get(Object key, Class<T> type) {
        return null;
    }

    @Override
    public <T> T get(Object key, Callable<T> valueLoader) {
        return null;
    }

    @Override
    public void put(Object key, Object value) {

    }

    @Override
    public ValueWrapper putIfAbsent(Object key, Object value) {
        return Cache.super.putIfAbsent(key, value);
    }

    @Override
    public String getName() {
        return "";
    }

    @Override
    public Object getNativeCache() {
        return null;
    }
}
